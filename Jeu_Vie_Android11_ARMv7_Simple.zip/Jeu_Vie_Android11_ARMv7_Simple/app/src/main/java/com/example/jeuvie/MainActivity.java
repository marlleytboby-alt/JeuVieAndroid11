package com.example.jeuvie;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    int faim=75, energie=75, bonheur=65, argent=50, jour=1;
    TextView stats;

    int c(int n) { return Math.max(0, Math.min(100,n)); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        construire();
    }

    void construire() {
        LinearLayout r=new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER_HORIZONTAL);
        r.setPadding(16,20,16,16);

        TextView t=new TextView(this);
        t.setText("MA PETITE VIE");
        t.setTextSize(25);
        r.addView(t);

        stats=new TextView(this);
        stats.setTextSize(18);
        stats.setGravity(Gravity.CENTER);
        r.addView(stats);

        bouton(r,"Manger (-5 €)",0);
        bouton(r,"Dormir",1);
        bouton(r,"Travailler (+20 €)",2);
        bouton(r,"Loisir (-8 €)",3);
        bouton(r,"Fin de journée",4);

        setContentView(r);
        maj();
    }

    void bouton(LinearLayout r,String texte,final int a) {
        Button b=new Button(this);
        b.setText(texte);
        b.setOnClickListener(v -> {
            if(a==0 && argent>=5){argent-=5; faim+=25; bonheur+=2;}
            else if(a==1){energie+=35; faim-=8;}
            else if(a==2){argent+=20; energie-=18; faim-=8; bonheur-=2;}
            else if(a==3 && argent>=8){argent-=8; bonheur+=20; energie-=5;}
            else if(a==4){jour++; faim-=12; energie-=10; bonheur-=4;}
            maj();
        });
        r.addView(b);
    }

    void maj() {
        stats.setText("Jour "+jour+"\n\n"+
            "Faim : "+c(faim)+"%\n"+
            "Énergie : "+c(energie)+"%\n"+
            "Bonheur : "+c(bonheur)+"%\n"+
            "Argent : "+Math.max(0,argent)+" €");
    }
}
