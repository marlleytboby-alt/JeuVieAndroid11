# Jeu Vie — Android 11 / ARMv7 32 bits

Projet minimal : Java uniquement, aucune bibliothèque externe, aucune image,
aucune musique et aucune connexion Internet.

Cible : Android 11, minSdk 21, targetSdk 28.
Compilation : Java/JDK 11 + Android Gradle Plugin 7.4.x.
Le projet conserve la cible armeabi-v7a. Aucun NDK n'est nécessaire car le jeu
n'utilise pas de code natif.
