package com.jeuvie.original;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.content.Intent;
import android.view.*;
import android.widget.*;

public class MapActivity extends Activity {
    FrameLayout frame;
    ImageView map;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        frame = new FrameLayout(this);
        map = new ImageView(this);
        map.setImageResource(R.drawable.ville_map);
        map.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(map, new FrameLayout.LayoutParams(-1,-1));

        map.post(() -> {
            addHotspot("Maison", .20f,.24f,.12f,.10f);
            addHotspot("Parc", .42f,.18f,.16f,.10f);
            addHotspot("École / Université", .61f,.20f,.18f,.11f);
            addHotspot("Hôpital", .79f,.23f,.13f,.11f);
            addHotspot("Magasin", .29f,.39f,.15f,.11f);
            addHotspot("Restaurant", .48f,.37f,.16f,.11f);
            addHotspot("Salle de sport", .68f,.39f,.15f,.11f);
            addHotspot("Travail", .61f,.54f,.13f,.10f);
            addHotspot("Centre-ville", .43f,.63f,.17f,.10f);
            addHotspot("Plage", .09f,.34f,.12f,.10f);
            addHotspot("Port", .09f,.79f,.12f,.10f);
            addHotspot("QG Mafia", .77f,.50f,.15f,.11f);
            addHotspot("Bar", .28f,.67f,.12f,.10f);
            addHotspot("Club", .42f,.82f,.12f,.10f);
            addHotspot("Usine", .20f,.83f,.12f,.10f);
            addHotspot("Quartier résidentiel", .78f,.70f,.20f,.11f);
        });

        Button back = new Button(this);
        back.setText("← Retour");
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(150,65);
        bp.leftMargin=15; bp.topMargin=15;
        frame.addView(back,bp);
        back.setOnClickListener(v -> finish());
        setContentView(frame);
    }

    void addHotspot(String name,float x,float y,float w,float h) {
        Button b=new Button(this);
        b.setText(name); b.setTextSize(10); b.setTextColor(Color.WHITE);
        b.setBackground(new ColorDrawable(Color.argb(130,0,0,0)));
        b.setOnClickListener(v -> openPlace(name));
        int fw=frame.getWidth(), fh=frame.getHeight();
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams((int)(fw*w),(int)(fh*h));
        p.leftMargin=(int)(fw*x); p.topMargin=(int)(fh*y);
        frame.addView(b,p);
    }

    void openPlace(String name) {
        String message;
        if(name.equals("Maison")) message="🏠 Maison\nDormir, sauvegarder et récupérer de l'énergie.";
        else if(name.equals("Restaurant")) message="🍔 Restaurant\nManger pour récupérer de la faim.";
        else if(name.equals("Magasin")) message="🛒 Magasin\nAcheter des objets utiles pour ton aventure.";
        else if(name.equals("École / Université")) message="🎓 École / Université\nRencontrer des personnages et débloquer des dialogues.";
        else if(name.equals("Travail")) message="💼 Travail\nChoisir un emploi légal et gagner de l'argent.";
        else if(name.equals("QG Mafia")) message="🕶️ QG Mafia\nTon contact peut te proposer une mission clandestine.";
        else if(name.equals("Plage")) message="🏖️ Plage\nUn endroit pour te détendre et rencontrer des gens.";
        else if(name.equals("Parc")) message="🌳 Parc\nPromenade et événements avec les personnages.";
        else if(name.equals("Hôpital")) message="🏥 Hôpital\nSoins et événements spéciaux.";
        else if(name.equals("Salle de sport")) message="🏋️ Salle de sport\nAméliorer ta forme et ton énergie maximale.";
        else if(name.equals("Bar")) message="🍸 Bar\nDiscussions et nouvelles rencontres le soir.";
        else if(name.equals("Club")) message="🎵 Club\nÉvénements nocturnes et personnages.";
        else if(name.equals("Port")) message="⚓ Port\nUn quartier où certaines missions peuvent apparaître.";
        else if(name.equals("Usine")) message="🏭 Usine\nPossibilité de travail et événements.";
        else if(name.equals("Centre-ville")) message="🌆 Centre-ville\nBoutiques, rencontres et quêtes.";
        else message="🏘️ Quartier résidentiel\nDe nouvelles maisons et personnages seront accessibles ici.";

        new AlertDialog.Builder(this)
            .setTitle(name)
            .setMessage(message)
            .setPositiveButton(name.equals("QG Mafia") ? "Faire la mission" : "Entrer", (d, which) -> {
                Intent i=new Intent(); i.putExtra("place",name); setResult(RESULT_OK,i); finish();
            })
            .setNegativeButton("Fermer",null).show();
    }
}
