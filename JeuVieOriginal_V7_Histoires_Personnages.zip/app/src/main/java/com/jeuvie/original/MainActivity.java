package com.jeuvie.original;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int day=1,money=50,hunger=75,energy=80,happiness=70;
    int reputation=0,relation=0,mafiaLevel=0;
    android.content.SharedPreferences gamePrefs;
    TextView dayView,stats,story;
    LinearLayout choices;
    static final int MAP_REQUEST=10;

    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        gamePrefs=getSharedPreferences("game",0); day=gamePrefs.getInt("day",1);
        dayView=findViewById(R.id.day); stats=findViewById(R.id.stats);
        story=findViewById(R.id.story); choices=findViewById(R.id.choices); update();
        findViewById(R.id.map).setOnClickListener(v -> startActivityForResult(new Intent(this,MapActivity.class),MAP_REQUEST));
        findViewById(R.id.characters).setOnClickListener(v -> startActivity(new Intent(this,CharactersActivity.class)));
        findViewById(R.id.talk).setOnClickListener(v -> dialogue());
        findViewById(R.id.choice1).setOnClickListener(v -> choose(1));
        findViewById(R.id.choice2).setOnClickListener(v -> choose(2));
        findViewById(R.id.choice3).setOnClickListener(v -> choose(3));
        findViewById(R.id.mafia).setOnClickListener(v -> mafiaMission());
        findViewById(R.id.eat).setOnClickListener(v -> { if(money>=5){money-=5;hunger=Math.min(100,hunger+25);happiness=Math.min(100,happiness+3);story.setText("Tu manges tranquillement.");}else story.setText("Tu n'as pas assez d'argent.");update(); });
        findViewById(R.id.work).setOnClickListener(v -> {money+=20;energy=Math.max(0,energy-25);hunger=Math.max(0,hunger-8);story.setText("Ton travail légal est terminé. +20 €.");update();});
        findViewById(R.id.rest).setOnClickListener(v -> {energy=Math.min(100,energy+30);hunger=Math.max(0,hunger-8);story.setText("Tu te reposes.");update();});
        findViewById(R.id.explore).setOnClickListener(v -> {energy=Math.max(0,energy-10);happiness=Math.min(100,happiness+8);story.setText("Tu explores la ville et découvres de nouveaux endroits.");update();});
        findViewById(R.id.end).setOnClickListener(v -> {day++;hunger=Math.max(0,hunger-10);energy=100;gamePrefs.edit().putInt("day",day).apply();story.setText("Jour "+day+". Une nouvelle journée commence. De nouvelles scènes peuvent être disponibles.");update();});
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==MAP_REQUEST && resultCode==RESULT_OK && data!=null){
            String place=data.getStringExtra("place");
            if("Maison".equals(place)){energy=Math.min(100,energy+35);story.setText("Tu rentres chez toi et récupères de l'énergie.");}
            else if("Restaurant".equals(place)){if(money>=8){money-=8;hunger=Math.min(100,hunger+35);happiness=Math.min(100,happiness+4);story.setText("Tu prends un repas au restaurant. -8 €.");}else story.setText("Tu n'as pas assez d'argent pour le restaurant.");}
            else if("Travail".equals(place)){money+=20;energy=Math.max(0,energy-20);story.setText("Tu fais une journée de travail légal. +20 €.");}
            else if(place.contains("École")||"Parc".equals(place)||"Bar".equals(place)||"Club".equals(place)||"Port".equals(place)||"Hôpital".equals(place)||"Restaurant".equals(place)){story.setText("Tu arrives à "+place+". Des personnages sont disponibles."); startActivity(new Intent(this,CharactersActivity.class));}
            else if("QG Mafia".equals(place)){mafiaMission();return;}
            else if("Parc".equals(place)||"Plage".equals(place)){happiness=Math.min(100,happiness+12);energy=Math.max(0,energy-8);story.setText("Tu passes du temps à "+place.toLowerCase()+". Bonheur +12.");}
            else if("Salle de sport".equals(place)){energy=Math.max(0,energy-12);happiness=Math.min(100,happiness+5);story.setText("Tu t'entraînes. Tu te sens mieux.");}
            else story.setText("Tu arrives à : "+place+". De nouveaux événements pourront s'y dérouler.");
            update();
        }
    }

    void dialogue(){story.setText("Léo : « Salut. J'ai une proposition pour toi. Qu'est-ce que tu en penses ? »");((Button)findViewById(R.id.choice1)).setText("Je t'écoute.");((Button)findViewById(R.id.choice2)).setText("Ça dépend de la récompense.");((Button)findViewById(R.id.choice3)).setText("Non merci.");choices.setVisibility(View.VISIBLE);}
    void choose(int c){if(c==1){relation+=3;gamePrefs.edit().putInt("relation_leo",relation).apply();happiness+=3;story.setText("Léo apprécie ta confiance. Relation +3.");}if(c==2){relation+=1;gamePrefs.edit().putInt("relation_leo",relation).apply();money+=5;story.setText("Léo aime ton côté direct. +5 €.");}if(c==3){relation-=2;gamePrefs.edit().putInt("relation_leo",relation).apply();story.setText("Léo semble déçu. Relation -2.");}hideChoices();update();}
    void mafiaMission(){if(energy<25){story.setText("Le contact : « Reviens quand tu seras en forme. »");update();return;}mafiaLevel++;int reward=40+mafiaLevel*10;money+=reward;energy-=25;reputation+=4;happiness=Math.max(0,happiness-2);story.setText("Mission clandestine réussie. +"+reward+" €. Niveau Mafia : "+mafiaLevel+".");update();}
    void hideChoices(){choices.setVisibility(View.GONE);}
    void update(){ relation=gamePrefs.getInt("relation_leo",relation); dayView.setText("Jour "+day);stats.setText("Faim : "+Math.max(0,hunger)+"%\nÉnergie : "+energy+"%\nBonheur : "+Math.min(100,happiness)+"%\nArgent : "+money+" €\nRéputation : "+reputation+"\nRelation avec Léo : "+relation+"\nNiveau Mafia : "+mafiaLevel);}
}
