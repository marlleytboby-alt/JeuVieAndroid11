package com.jeuvie.original;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.SharedPreferences;
import android.widget.*;
import java.util.*;

public class CharactersActivity extends Activity {
    LinearLayout list;
    SharedPreferences prefs;
    String[][] chars = {
        {"Léo","Ami d'enfance","Parc","Vous vous connaissez depuis l'enfance. Léo cache parfois ses soucis derrière l'humour."},
        {"Emma","Étudiante","École / Université","Emma veut comprendre la ville et rêve de monter son propre projet."},
        {"Sarah","Serveuse","Restaurant","Sarah observe tout ce qui se passe au restaurant et connaît les rumeurs du quartier."},
        {"Nina","Coach","Salle de sport","Nina est exigeante mais juste. Elle veut t'apprendre à ne jamais abandonner."},
        {"Marc","Mécanicien","Port","Marc répare les bateaux. Il est discret et préfère les actes aux paroles."},
        {"Julie","Médecin","Hôpital","Julie aide les habitants et remarque rapidement quand quelqu'un va mal."},
        {"Tommy","Contact","QG Mafia","Tommy travaille pour un réseau criminel fictif. Il ne dit jamais tout ce qu'il sait."},
        {"Alex","DJ","Club","Alex connaît la vie nocturne et entend souvent parler des événements avant les autres."}
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences("relations",0);
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(18,18,18,18); page.setBackgroundColor(Color.rgb(25,25,35));
        TextView title=new TextView(this); title.setText("👥 PERSONNAGES"); title.setTextSize(26); title.setTextColor(Color.WHITE); title.setGravity(17); title.setPadding(0,10,0,18); page.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView intro=new TextView(this); intro.setText("Chaque personnage possède sa propre histoire. Les jours, tes relations et tes choix peuvent débloquer de nouvelles scènes."); intro.setTextColor(Color.WHITE); intro.setTextSize(16); intro.setPadding(0,0,0,14); page.addView(intro);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        for(String[] c:chars) addCharacter(page,c);
        page.addView(list,new LinearLayout.LayoutParams(-1,-2));
        Button back=new Button(this); back.setText("← Retour"); back.setOnClickListener(v->finish()); page.addView(back); setContentView(page);
    }

    void addCharacter(LinearLayout page,String[] c){
        int rel=prefs.getInt(c[0].equals("Léo")?"relation_leo":"rel_"+c[0],0);
        Button b=new Button(this); b.setText(c[0]+" — "+c[1]+"  ♥ "+rel+"\n📍 "+c[2]); b.setTextSize(15); b.setAllCaps(false);
        b.setOnClickListener(v->dialogue(c)); page.addView(b,new LinearLayout.LayoutParams(-1,92));
    }

    void dialogue(String[] c){
        String name=c[0], job=c[1], place=c[2], bio=c[3];
        int rel=prefs.getInt(name.equals("Léo")?"relation_leo":"rel_"+name,0); int day=getSharedPreferences("game",0).getInt("day",1);
        String intro;
        if(name.equals("Léo")) intro=day<3?"Léo : « Ça fait plaisir de te revoir. On devrait reprendre nos habitudes. »":"Léo : « J'ai quelque chose d'important à te raconter… mais je dois savoir si je peux te faire confiance. »";
        else if(name.equals("Emma")) intro=day<4?"Emma : « Je découvre encore la ville. Tu connais un bon endroit pour discuter ? »":"Emma : « J'ai trouvé quelque chose d'étrange dans mes recherches. Tu veux m'aider à comprendre ? »";
        else if(name.equals("Sarah")) intro=day<5?"Sarah : « Une journée normale au restaurant… enfin, presque. »":"Sarah : « J'ai entendu une rumeur sur le port. Promets-moi de rester prudent. »";
        else if(name.equals("Nina")) intro=rel>=6?"Nina : « Tu progresses vraiment. Je peux te montrer un entraînement spécial. »":"Nina : « Alors, prêt à te dépasser aujourd'hui ? »";
        else if(name.equals("Marc")) intro=rel>=5?"Marc : « J'ai une vieille histoire de bateau à te raconter. »":"Marc : « Si tu veux parler, fais vite. J'ai du travail. »";
        else if(name.equals("Julie")) intro=rel>=6?"Julie : « Tu peux me parler franchement. Je ne te jugerai pas. »":"Julie : « Tu as l'air fatigué. Prends soin de toi. »";
        else if(name.equals("Tommy")) intro=rel>=8?"Tommy : « Tu as gagné ma confiance. Une affaire importante se prépare. »":"Tommy : « Je peux te proposer du travail. Rien de plus. »";
        else intro=day<6?"Alex : « Ce soir, le club va être animé. Tu viens ? »":"Alex : « J'ai entendu parler d'une soirée privée. Ça pourrait changer tes rencontres. »";

        String[] replies={"Être honnête et écouter.","Poser des questions et proposer ton aide.","Couper court à la discussion."};
        AlertDialog.Builder box=new AlertDialog.Builder(this); LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(25,10,25,10);
        TextView t=new TextView(this); t.setText(name+" — "+job+"\n\n"+bio+"\n\n📅 Jour "+day+"\n♥ Relation : "+rel+"\n\n💬 "+intro); t.setTextSize(17); panel.addView(t);
        for(int i=0;i<3;i++){ Button r=new Button(this); r.setText(replies[i]); r.setAllCaps(false); final int choice=i; r.setOnClickListener(v->{
            int delta=choice==0?2:(choice==1?3:-2); int nr=Math.max(0,Math.min(20,prefs.getInt(name.equals("Léo")?"relation_leo":"rel_"+name,0)+delta)); prefs.edit().putInt(name.equals("Léo")?"relation_leo":"rel_"+name,nr).apply();
            String unlock=sceneUnlock(name,nr,day); t.setText(name+"\n\n"+(delta>0?"La relation progresse : +"+delta:"La relation baisse : "+delta)+".\n♥ Relation : "+nr+"\n\n"+unlock); panel.removeViews(1,panel.getChildCount()-1);
        }); panel.addView(r); }
        box.setTitle(name); box.setView(panel); box.setPositiveButton("Fermer",null); box.show();
    }

    String sceneUnlock(String name,int rel,int day){
        if(name.equals("Tommy") && rel>=8) return "🔓 Scène débloquée : Tommy te propose une affaire importante. Les missions restent entièrement fictives et scénarisées.";
        if(name.equals("Léo") && rel>=6) return "🔓 Scène débloquée : Léo te confie enfin ce qui le préoccupe depuis plusieurs jours.";
        if(name.equals("Emma") && rel>=6) return "🔓 Scène débloquée : Emma t'invite à enquêter avec elle sur un mystère de la ville.";
        if(rel>=5) return "🔓 Une nouvelle conversation sera disponible dans les prochains jours.";
        if(day>=7) return "📅 De nouvelles scènes apparaîtront à mesure que les jours passent.";
        return "Continue à parler avec cette personne pour découvrir son histoire.";
    }
}
